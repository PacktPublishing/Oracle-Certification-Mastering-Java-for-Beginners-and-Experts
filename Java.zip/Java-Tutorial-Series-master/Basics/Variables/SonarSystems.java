
public class SonarSystems {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		int hello = 9;
		
		age = 26;
		
		System.out.println(age);
		
		
		System.out.println(hello);
		
		hello = -6;
		
		System.out.println(hello);
	}

}
