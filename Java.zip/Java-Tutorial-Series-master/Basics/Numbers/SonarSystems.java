
public class SonarSystems {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		      
		float i = 59.6f;
		
		// Round
		System.out.println(Math.round(i));
		
		// Log
		System.out.println(Math.E);
		System.out.println(Math.log(100));
		
		// Power
		System.out.println(Math.pow(10, 5));
		
		// Square root
		System.out.println(Math.sqrt(4));
		
		// Sine (Trigonometry)
		double pi = Math.PI;
		System.out.println(Math.sin(pi));
	}

}
