
public class SonarSystems {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		      
		String str = "Hello World";
		
		System.out.println(str);
		
		// Character location
		System.out.println(str.charAt(0));
		
		// String length
		System.out.println(str.length());
		
		// Convert string to uppercase
		System.out.println(str.toUpperCase());
	}

}
