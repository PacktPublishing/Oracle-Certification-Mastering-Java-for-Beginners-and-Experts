
public class SonarSystems {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		final float pi = 3.14159f;
		
		System.out.println( pi );
		
		System.out.println( pi );
	}

}
