
public class SonarSystems {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		      
		int i = 11;
		
		if (i > 4 || i < 10)
		{
			System.out.println("Yay, value is 4");
		}
		else if (i == 5)
		{
			System.out.println("Not as good, but value is 5");	
		}
		else if (i == 6)
		{
			System.out.println("6");	
		}
		else
		{
			System.out.println("Fallback");
		}
	}

}
