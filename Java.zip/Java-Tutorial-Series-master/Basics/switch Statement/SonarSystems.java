
public class SonarSystems {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		      
		/*int i = 11;
		
		if (i > 4 || i < 10)
		{
			System.out.println("Yay, value is 4");
		}
		else if (i == 5)
		{
			System.out.println("Not as good, but value is 5");	
		}
		else if (i == 6)
		{
			System.out.println("6");	
		}
		else
		{
			System.out.println("Fallback");
		}*/
		
		int x = 0;
		
		switch (x)
		{
			case 0:
				System.out.println("Number 0");
				//break;
				
			case 1:
				System.out.println("Number 1");
				//break;
				
			case 2:
				System.out.println("Number 2");
				//break;
				
			case 3:
				System.out.println("Number 3");
				break;
				
			case 4:
				System.out.println("Number 4");
				break;
				
			case 5:
				System.out.println("Number 5");
				break;
				
			default:
				System.out.println("Not valid");
		}
	}

}
