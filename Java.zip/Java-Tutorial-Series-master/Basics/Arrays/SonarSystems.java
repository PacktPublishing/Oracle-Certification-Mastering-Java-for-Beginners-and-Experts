
public class SonarSystems {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		// int arr[] or int[] arr, they are the same
		int arr[] = {1, 2, 3, 4, 5, 6, 7, 8, 90, 4, 23, 4};
		
		//System.out.println(arr[5]);
		
		//System.out.println(arr.length);
		
		// loop through the array and print out all values
		for (int i = 0; i < arr.length; i++)
		{
			System.out.println(arr[i]);
		}
	}

}
