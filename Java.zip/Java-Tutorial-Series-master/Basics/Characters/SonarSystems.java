
public class SonarSystems {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		      
		char c = '\t';
		
		System.out.println(c + "Hello" + c + "World");
		
		char awesome = 'b';
		
		// Check if it is a letter
		System.out.println(Character.isLetter(awesome));
		
		// Check if it is uppercase
		System.out.println(Character.isUpperCase(awesome));
		
		// Convert lowercase to uppercase
		System.out.println(Character.toUpperCase(awesome));
	}

}
