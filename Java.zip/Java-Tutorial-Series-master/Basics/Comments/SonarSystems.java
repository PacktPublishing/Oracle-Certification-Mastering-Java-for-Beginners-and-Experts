// Awesome application


public class SonarSystems {

	// This is the main method
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Print Line");
		// This is a print without a new line
		System.out.print("Print\n");
		
		/*
		 * This is awesome
		 * Hello I am Awesome
		 * And you are awesome!!!!
		 */
		/*
		System.out.println("Print Line 3");
		System.out.println("Print Line 3");
		System.out.println("Print Line 3");
		System.out.println("Print Line 3");
		System.out.println("Print Line 3");
		System.out.println("Print Line 3");
		
		*/
	}

}
