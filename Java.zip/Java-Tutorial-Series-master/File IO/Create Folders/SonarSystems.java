import java.io.File;

public class SonarSystems {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		String directory = "/Users/SonarSystems/Desktop/Hello/Awesome/World";
		File f = new File(directory);
		
		f.mkdirs();
	}
	
}
