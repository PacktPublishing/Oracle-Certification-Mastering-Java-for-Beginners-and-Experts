
public class SonarSystems {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		int array[] = new int[10];
		
		/*try
		{*/
			System.out.println(array[10]);
		/*}
		catch (ArrayIndexOutOfBoundsException error)
		{
			System.out.println(error);
		}*/
		
		System.out.println("End");
	}
	
}
