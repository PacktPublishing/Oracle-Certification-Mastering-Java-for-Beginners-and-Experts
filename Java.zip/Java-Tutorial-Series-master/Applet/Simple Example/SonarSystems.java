import java.applet.*;
import java.awt.*;

public class SonarSystems extends Applet
{
	public void init()
	{
		
	}
	
	public void start()
	{
		
	}
	
	public void stop()
	{
		
	}
	
	public void destroy()
	{
		
	}
	
	public void paint(Graphics grph)
	{
		grph.drawString("I am Frahaan", 100, 67);
	}
}