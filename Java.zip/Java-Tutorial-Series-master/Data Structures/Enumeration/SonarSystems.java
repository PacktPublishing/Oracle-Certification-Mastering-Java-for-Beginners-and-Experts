

public class SonarSystems {
	public enum Animals
	{
		DOG,
		CAT,
		COW,
		LION
	}
	
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Animals a = Animals.CAT;
		
		if (a == Animals.DOG)
		{
			System.out.println("True");
		}
	}
}