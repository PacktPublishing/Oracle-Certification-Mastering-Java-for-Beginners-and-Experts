import java.util.*;
public class SonarSystems {
	
	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		Map mappy = new HashMap();
		
		mappy.put("Key1", "Value1");
		mappy.put("Key2", "Value2");
		mappy.put("Key3", "Value3");
		mappy.put("Key4", "Value4");
		mappy.put("Key5", "Value5");
		mappy.put("Key6", "Value6");
		
		System.out.println(mappy);
		
		System.out.println(mappy.get("Key6"));
	}
}