package sonar;

public class SuperEnemy extends Character
{
	public SuperEnemy()
	{
		this.health = 1000;
	}
}
