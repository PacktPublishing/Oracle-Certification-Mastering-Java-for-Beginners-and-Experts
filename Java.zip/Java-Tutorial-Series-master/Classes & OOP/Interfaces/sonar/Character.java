package sonar;

public interface Character
{	
	public void ReduceHealth(int damage);
}
