
public class SonarSystems {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		Function1();
		
		int i = ReturnFunction();
		
		System.out.println(i);
	}

	public static void Function1()
	{
		System.out.println(5);
	}
	
	public static int ReturnFunction()
	{
		int x = 8;
		return 6 * 2 + x;
	}
}
