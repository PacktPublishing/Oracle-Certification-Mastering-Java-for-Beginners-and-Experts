
public class SonarSystems {

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		
		System.out.println("Welcome to this application :D");
		
		for (String str: args)
		{
			System.out.println(str);
		}
	}
	
}
